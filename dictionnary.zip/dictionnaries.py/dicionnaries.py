import textfile 

def most_frequentwords(the filename):
    words =[]
    with open(textfile.txt, "r") as file:
       textlines = textfile.readlines()
       for w in textlines:
           words.append(word)
    return words 
   
most_frequentwords= top5_words(). most_frequentwords("the filename")
print("the 5 most commun words are: ")
for word, count in  most_frequentwords:
    print(f"'{word}: {count}")

top5_words= "textfile.txt"


dct = {}

dct['word'] = dct.get('word', 0) + 1
most_frequentwords(top5_words)