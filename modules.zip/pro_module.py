
#then we will calculate the sum, difference, product and quotient of the two number he/she  provides 
def sum_result(num1, num2): 
    return num1 + num2 

def difference( num1, num2):
    return num1 - num2
def product(num1, num2):
    return num1 * num2
def quotient (num1, num2):
    try:
        return num1 / num2 
    except ZeroDivisionError:
        return "Error, Cannot divide by zero "
