
def all_result(num1, num2, sum_)
with open("calculations.txt", "a") as file:
    file.write(f"The sum of {num1} and {num2} is {sum_result}\n")
    file.write(f"The difference between {num1} and {num2} is {diff_result}\n")
    file.write(f"The product of {num1} and {num2} is {prod_result}\n")
    file.write(f"The quotient of {num1} and {num2} is {quot_result}\n")