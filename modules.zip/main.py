from in_module  import twonumber
from pro_module import sum, diffence, product, quotient 
from out_module import display_results, append_to_file
from in_module  import num1, num2 

sum_result= num1 + num2 
difference= num1 - num2
product= num1 * num2
quotient= num1 / num2