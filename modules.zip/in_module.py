#First we ask the user to eneter two number 
def twonumber():
    try:
        num1= float(input ("enter numeber 1 "))
        num2= float(input ("enter number 2 "))
        return num1, num2 
    except ValueError:
        print("Invalid input, please try again.")
        return twonumber()